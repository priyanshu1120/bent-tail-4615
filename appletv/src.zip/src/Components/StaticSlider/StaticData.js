export const  StaticData = [
    {
      image: "https://is1-ssl.mzstatic.com/image/thumb/Features122/v4/26/b9/09/26b90992-e05e-5543-67bb-10f6bbe92533/afa01abf-9dd9-4a8b-afef-33c88a248881.png/1319x494sr.webp",
    },

    {
      image: "https://is5-ssl.mzstatic.com/image/thumb/Features122/v4/fa/08/b5/fa08b55d-9e77-43c3-1c61-3271035fe1a1/1d8cc21a-b9cb-4c60-9e6e-e0b1682d9c99.png/1998x748sr.webp",
    },

    {
      image: "https://is3-ssl.mzstatic.com/image/thumb/Features122/v4/80/61/6e/80616e81-7ec9-a6b9-46f9-d3efe9d5a329/9f9ae409-8a1b-4ab2-bc97-ef3b488b3f41.png/999x374sr.webp",
    },
    {
        image: "https://is3-ssl.mzstatic.com/image/thumb/Features112/v4/4b/75/e8/4b75e836-e89d-3133-7bb5-952ab6bb199d/356abd94-9324-404a-afc3-0ffc03283736.png/1319x494sr.webp",
     },
  
     {
        image: "https://is1-ssl.mzstatic.com/image/thumb/Features112/v4/75/68/c1/7568c183-0aa6-682b-0fce-ddb127ca9122/ca680115-7e6f-4244-9fa4-22cbc8c60ae7.png/1319x494sr.webp",
    },
    {
        image:"https://is4-ssl.mzstatic.com/image/thumb/Features122/v4/16/a9/ac/16a9ac3a-1393-438b-6a58-74ecbee7310d/c57aa982-fc8f-4ed2-9c2d-ee218db83880.png/1319x494sr.webp"
    },
    {
       image:"https://is3-ssl.mzstatic.com/image/thumb/Features122/v4/7a/b2/62/7ab262f1-e794-f2a6-0e54-6077976a0389/2f2f924b-070d-49b0-8c5c-68dabac961b6.png/2638x988sr.webp"
    },
    {
        image:"https://is2-ssl.mzstatic.com/image/thumb/Features122/v4/f5/3e/79/f53e7943-0141-8f79-0166-64b0506a4ba3/46e266e1-afb9-4b04-a19d-1f9eb7a47763.png/2638x988sr.webp"
    }
  ];


  export const  static2 = [
    {
      image: "https://is1-ssl.mzstatic.com/image/thumb/Features112/v4/43/6c/99/436c9926-2923-ba9e-4b53-2d1f81d17937/be42058d-d26b-444d-b57f-37c78213344e.png/400x610tc.webp",
    },

    {
      image: "https://is1-ssl.mzstatic.com/image/thumb/Features122/v4/b1/86/10/b186109b-98e8-73a6-3262-8c336f50ea39/e0c7fc1e-3932-4a86-a430-0892362a82d9.png/800x1220tc.webp",
    },

 
    {
        image: "https://is2-ssl.mzstatic.com/image/thumb/Features122/v4/c4/35/35/c43535a9-ec6f-0972-4b06-38b21e859de7/07260630-e569-4c62-9e5b-7327e46b4c5c.png/800x1220tc.webp",
     },
  
     {
      image: "https://is1-ssl.mzstatic.com/image/thumb/Features122/v4/b1/86/10/b186109b-98e8-73a6-3262-8c336f50ea39/e0c7fc1e-3932-4a86-a430-0892362a82d9.png/800x1220tc.webp",
    },
    {
        image:"https://is2-ssl.mzstatic.com/image/thumb/Features122/v4/c4/35/35/c43535a9-ec6f-0972-4b06-38b21e859de7/07260630-e569-4c62-9e5b-7327e46b4c5c.png/800x1220tc.webp"
    }

  ];



  export const sliderdata2 = [
    {
   
      linkImg:
        'https://is3-ssl.mzstatic.com/image/thumb/Features122/v4/64/55/f2/6455f286-211a-6b8f-234b-19f338149c46/aa9af5e8-a94e-45f1-b7fc-7001290bacba.lsr/1478x832fe.webp',
    },
    {
   
      linkImg:
        'https://is2-ssl.mzstatic.com/image/thumb/Features112/v4/c0/92/6a/c0926af4-8b56-442e-9c48-cf7eed2b2053/11ccb293-2a86-4928-95a6-ff952267df68.lsr/1478x832fe.webp',
    },
    {
   
      linkImg:
        'https://is5-ssl.mzstatic.com/image/thumb/Features122/v4/c2/8b/ad/c28bad4f-16ea-59b4-4d64-ad27d50503af/888dacc8-7cac-4446-bcb7-70a70cfbe26e.lsr/1478x832fe.webp',
    },
    {
    
      linkImg:
        'https://is5-ssl.mzstatic.com/image/thumb/Features122/v4/c2/8b/ad/c28bad4f-16ea-59b4-4d64-ad27d50503af/888dacc8-7cac-4446-bcb7-70a70cfbe26e.lsr/1478x832fe.webp',
    },

    {
  
      linkImg:
        'https://is3-ssl.mzstatic.com/image/thumb/Features122/v4/40/a5/6a/40a56a15-9da2-967c-d69b-a5052bb404c5/89d54294-ded9-4ccc-859b-d5c5442c7682.lsr/1478x832fe.webp',
    },
    {

      linkImg:
        'https://is4-ssl.mzstatic.com/image/thumb/Features116/v4/f8/7b/74/f87b74f9-ef7d-66c7-de75-6f621b9b800a/8c24d846-b3ad-4283-8424-4c055824358b.lsr/1478x832fe.webp',
    },
    {
   
      linkImg:
        'https://is5-ssl.mzstatic.com/image/thumb/Features122/v4/50/62/c0/5062c0ba-9947-951a-9746-c2a8a6bbcb1d/3f5b9e26-ff9a-417a-aa68-88b07170a907.lsr/1478x832fe.webp',
    },
  ];


  export const sliderdata3 = [
    {
   
      linkImg:
        'https://is2-ssl.mzstatic.com/image/thumb/Features112/v4/69/26/cb/6926cb49-3cdd-7db7-69c2-ed1d86d24265/e864cc33-c756-468f-983a-c8c1c2bb1adb.lsr/1478x832fe.webp',
    },
    {
   
      linkImg:
        'https://is5-ssl.mzstatic.com/image/thumb/Features122/v4/44/f2/ac/44f2aca2-6715-4154-8bc9-ffc1e1d6689a/61a6e79a-db85-4774-b3e9-243c554f899d.lsr/1478x832fe.webp',
    },
    {
   
      linkImg:
        'https://is1-ssl.mzstatic.com/image/thumb/Features122/v4/f1/0c/a2/f10ca2b9-225f-d9bb-afeb-d5a21846cf75/0da18062-dcc4-45f5-855d-d3f45a6653cb.lsr/1478x832fe.webp',
    },
    {
    
      linkImg:
        'https://is5-ssl.mzstatic.com/image/thumb/Features122/v4/16/3c/3d/163c3d04-997e-1320-ae31-280552aa75a2/adb13250-11db-49f4-93dd-f81cf6e1d86f.lsr/1478x832fe.webp',
    },

    {
  
      linkImg:
        'https://is5-ssl.mzstatic.com/image/thumb/Features122/v4/12/3f/3d/123f3d42-a67d-8bf2-5098-44a3a3fecfe9/43c984ce-90d6-42c9-b837-8e18ec530e86.lsr/1478x832fe.webp',
    },
    {

      linkImg:
        'https://is2-ssl.mzstatic.com/image/thumb/Features112/v4/d0/fe/46/d0fe468f-a5bb-e698-d0c2-ca3e1b5f5fae/270aeaad-92dd-41c6-8c42-ef1dd046355e.lsr/1478x832fe.webp',
    },
 
  ];

